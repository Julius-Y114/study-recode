import qrcode
from tkinter import *
from tkinter import filedialog,messagebox
from PIL import Image,ImageTk


def generate_qr():
    data = entry.get()
    if not data.strip():
        messagebox.showwarning('Warning','Please enter some text or URL')
        return

    qr = qrcode.QRCode(
        version = 2,
        error_correction = qrcode.constants.ERROR_CORRECT_H,
        box_size = 10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)

    qr_img = qr.make_image()

    try:
        logo = Image.open('logo.png')
        logo_size = 80
        logo = logo.resize((logo_size,logo_size))
        pos = ((qr_img.size[0]-logo_size) // 2,(qr_img.size[1] - logo_size) // 2)
        qr_img.paste(logo,pos,mask=logo if logo.mode == 'RGBA' else None)
    except FileNotFoundError:
        pass

    file_path = filedialog.asksaveasfilename(defaultextension='.png',
                                             filetypes=[('PNG files','*.png')],
                                             title='Save QR Code As')
    if not file_path:
        return

    qr_img.save(file_path)

    resized = qr_img.resize((300,300))
    tk_img = ImageTk.PhotoImage(resized)
    qr_label.config(image = tk_img)
    qr_label.image = tk_img

    messagebox.showinfo("Success",f"QR code saved as:\n{file_path}")

root = Tk()
root.title('QR Code Generator')
root.geometry('460x650')
root.config(bg='#ffffff')
root.resizable(False,False)

Label(root,text='QR Code Generator',font=('Segoe UI',20,'bold'),fg='#333',bg='#ffffff').pack(pady=20)

entry_frame = Frame(root,bg='#ffffff')
entry_frame.pack(pady=10)

entry = Entry(entry_frame,font=('Segoe UI',14),width=35,bd=2,
              relief=SOLID,highlightthickness=2,highlightbackground='#ccc')
entry.pack(ipadx=8,ipady=10)

def on_enter(e):
    generate_button.config(bg='#43A047')

def on_leave(e):
    generate_button.config(bg='#4CAF50')

generate_button = Button(root,text='QR Code Generator',
                         font=('Segoe UI',13,'bold'),
                         bg='#4CAF50',
                         fg='white',
                         padx=20,pady=10,
                         bd = 0,relief=RAISED,
                         activebackground='#388EC3',
                         activeforeground='white',
                         command=generate_qr
)

generate_button.pack(pady=30)
generate_button.bind('<Enter>',on_enter)
generate_button.bind('<Enter>',on_leave)

qr_label = Label(root,bg='#ffffff')
qr_label.pack(pady=10)

root.mainloop()
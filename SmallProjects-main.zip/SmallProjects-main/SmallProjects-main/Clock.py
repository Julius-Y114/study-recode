from tkinter import *
from time import *

def update():
    timestring = strftime("%I:%M:%S %p")
    time_label.config(text=timestring)

    daystring = strftime("%A")
    day_label.config(text=daystring)

    datestring = strftime("%B %d,%Y")
    date_label.config(text=datestring)

    window.after(1000,update)

window = Tk() #instantiate an instance of a window
window.title('My Own Clock')

time_label = Label(window,font=('Arial',50),fg='#00FF00',bg='black')
time_label.pack()

day_label = Label(window,font=('Ink Free',25))
day_label.pack()

date_label = Label(window,font=('Ink Free',30))
date_label.pack()

update()

window.mainloop() #place window on computer screen, list for events